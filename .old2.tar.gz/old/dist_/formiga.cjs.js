'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var react = require('react');

var log = (w, s) => {
  {
    return;
  }
};

var useForm = () => {
  var formRef = react.useRef(undefined);
  var [valid, setValid] = react.useState(true);
  var readElements = react.useCallback(() => {
    if ((formRef === null || formRef === void 0 ? void 0 : formRef.current) == undefined) {
      return {};
    }

    var formElements = formRef.current.elements;

    if (!formElements) {
      return {};
    }

    var nElements = {};

    for (var idx = 0; idx < formElements.length; idx++) {
      var el = formElements.item(idx);
      var msg = el.getAttribute('data-formiga-validity') || '';
      var val = el.getAttribute('data-formiga-value') || '';

      var _valid = msg == '';

      nElements[el.name] = {
        valid: _valid,
        message: msg,
        value: val
      };
    }

    return nElements;
  }, []);
  var checkIsValid = react.useCallback(() => {
    var isValid = true;

    for (var v of Object.values(readElements())) {
      if (v.valid === false) {
        isValid = false;
        break;
      }
    }

    return isValid;
  }, [readElements]);
  react.useEffect(() => {
    if ((formRef === null || formRef === void 0 ? void 0 : formRef.current) == undefined) {
      return;
    }

    try {
      formRef.current.noValidate = true;
    } catch (e) {
      console.error(e);
    } // Initial check of form validity


    var isValid = checkIsValid();
    setValid(isValid);
  }, [checkIsValid]);
  react.useEffect(() => {
    if ((formRef === null || formRef === void 0 ? void 0 : formRef.current) == undefined) {
      return;
    }

    var formValidityListener = event => {
      var elName = event.detail.name; //const elValid= event.detail.valid
      //const validity= event.detail.validity

      var value = event.detail.value;
      var nValid = checkIsValid();
      log('form', "on ".concat(event.type, " ").concat(elName, ". Valid? ").concat(nValid, " (curr ").concat(valid, ") (value ").concat(value, ")"));

      if (valid != nValid) {
        setValid(nValid);
      }
    };

    formRef.current.addEventListener('formiga-form-change', formValidityListener); // clean listeners function

    var removeAllChangeListeners = () => {
      if (formRef && formRef.current != undefined) {
        formRef.current.removeEventListener('formiga-form-change', formValidityListener);
      }
    };
    return removeAllChangeListeners;
  }, [checkIsValid, valid]);
  return [formRef, valid, readElements];
};

// Check some props consistency
var checkProps = (input, doRepeat, doNotRepeat, inputFilter) => {
  var name = input.name;
  var inputType = input.type.toLowerCase(); // Check inputFilter

  if (inputFilter && ['text'].indexOf(inputType) < 0) {
    console.warn("Formiga: You passed inputFilter to the Input Element (".concat(name, ") of type (").concat(inputType, "), but it does not support it"));
  } // Check doRepeat


  if (doRepeat != undefined && doRepeat == name) {
    console.warn("Formiga: You passed doRepeat prop to the Input Element (".concat(name, ") with the same name"));
  } // Check doNotRepeat


  if (doNotRepeat != undefined && doNotRepeat == name) {
    console.warn("Formiga: You passed doNotRepeat prop to the Input Element (".concat(name, ") with the same name"));
  }
};

var useCheckProps = (inputRef, doRepeat, doNotRepeat, inputFilter) => {
  react.useEffect(() => {
    if (process.env.NODE_ENV !== "production") {
      if (inputRef != undefined && inputRef.current != undefined) {
        var input = inputRef.current;
        log('input', "".concat(input.name, " (").concat(input.type, ") #").concat(input.id, " useCheckProps()"));
        checkProps(input, doRepeat, doNotRepeat, inputFilter);
      }
    }
  }, [inputRef, doRepeat, doNotRepeat, inputFilter]);
};

/*
 * Predefined input filter by Formiga
 */
var FORMIGA_INPUT_FILTERS = {
  'int': /^-?\d+$/,
  'uint': /^\d+$/,
  'float': /^-?\d*[.,]?\d*$/,
  //'float'       : /[+-]?([0-9]*[.])?[0-9]+/,
  'dollar': /^-?\d*[.,]?\d{0,2}$/,
  //'euro'        : /^-?\d*[.,]?\d{0,2}$/,
  'latin': /^[a-z ]*$/i,
  'hexadecimal': /^[0-9a-f]*$/i
};

var _fltBase = regex => {
  return v => {
    if (v === undefined || v === '') {
      return true;
    }

    return regex.test(v);
  };
};

var makeInputFilter = (inputFilter, inputName) => {
  if (inputFilter == undefined || inputFilter === '') {
    return undefined;
  }

  if (typeof inputFilter === 'string') {
    var regex = FORMIGA_INPUT_FILTERS[inputFilter];

    if (regex === undefined) {
      console.error("Formiga: error on Input Element (".concat(inputName, "). (").concat(inputFilter, ") is not a valid inputFilter"));
      return undefined;
    }

    return _fltBase(regex);
  }

  if (inputFilter instanceof RegExp) {
    return _fltBase(inputFilter);
  }

  if (typeof inputFilter === "function") {
    return inputFilter;
  }

  console.error("Formiga: error on Input Element (".concat(inputName, "). (").concat(inputFilter, ") of type (").concat(typeof inputFilter, ") is not a valid inputFilter"));
  return undefined;
};

// ['input', 'keydown', 'keyup', 'mousedown', 'mouseup', 'select', 'contextmenu', 'drop'],
// But lets start simple and easy. 

var INPUT_FILTER_EVENT_TYPES = ['input', 'keydown', 'mousedown'];

var useInputFilter = (inputRef, inputFilter) => {
  react.useEffect(() => {
    if (inputFilter == undefined) {
      return;
    }

    var input = inputRef === null || inputRef === void 0 ? void 0 : inputRef.current;

    if (input == undefined) {
      return;
    }

    if (input.type.toLowerCase() != 'text') {
      return;
    }

    var allListeners = {}; // Input Filter listeners
    // Credits to:
    // https://stackoverflow.com/a/469362
    // https://jsfiddle.net/emkey08/zgvtjc51

    var theInputFilter = makeInputFilter(inputFilter, input.name); // init auxiliar properties

    input.oldValue = input.value;

    var filterEventListener = function filterEventListener(event) {
      if (theInputFilter(event.target.value)) {
        event.target.oldValue = event.target.value;
      } else if (Object.hasOwnProperty.call(event.target, "oldValue")) {
        var selectionStart = event.target.selectionStart;
        var selectionEnd = event.target.selectionEnd;
        event.target.value = event.target.oldValue;

        try {
          event.target.setSelectionRange(selectionStart - 1, selectionEnd - 1);
        } catch (e) {}
      } else {
        event.target.value = "";
      }
    };

    INPUT_FILTER_EVENT_TYPES.forEach(function (eventType) {
      input.addEventListener(eventType, filterEventListener);
      allListeners[eventType] = filterEventListener;
    }); // clean listeners function

    var removeAllChangeListeners = () => {
      if (input != undefined) {
        Object.keys(allListeners).map(eventType => {
          input.removeEventListener(eventType, allListeners[eventType]);
        });
      }
    }; // return clean function


    return removeAllChangeListeners;
  }, [inputRef, inputFilter]);
};

var EVENT_TYPES = {
  'checkbox': ['change'],
  // {change: 'click' , premature: []},
  'color': ['change', 'click'],
  // {change: 'change', premature: ['click']},
  'date': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'datetime-local': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'email': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'file': ['change'],
  // {change: 'change', premature: []},
  'hidden': ['change'],
  // {change: 'change', premature: []},
  'image': ['change'],
  // {change: 'change', premature: []},
  'month': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'number': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'password': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'radio': ['change', 'click'],
  // {change: 'change', premature: ['click']},
  'range': ['change', 'click'],
  // {change: 'change', premature: ['click']},
  'search': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'select-multiple': ['click'],
  // {change: 'click' , premature: []},
  'select-one': ['click'],
  // {change: 'click' , premature: []},
  'tel': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'text': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'textarea': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'time': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'url': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  'week': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  // Obsolete
  'datetime': ['change', 'keyup', 'paste'],
  // {change: 'change', premature: ['keyup', 'paste']},
  // No handler for these
  'button': [],
  // {change: '', premature: []},
  'reset': [],
  // {change: '', premature: []},
  'submit': [] // {change: '', premature: []} 

};

var getValidationEvents = inputType => {
  inputType = inputType.toLowerCase();
  return EVENT_TYPES[inputType];
};

var useValidationListener = (inputRef, handler) => {
  react.useEffect(() => {
    var input = inputRef === null || inputRef === void 0 ? void 0 : inputRef.current;

    if (input == undefined) {
      return;
    } //log('input', `${input.name} (${input.type}) #${input.id} useValidationListener()`)


    var validationEvents = getValidationEvents(input.type) || [];
    validationEvents.map(eventType => {
      input.addEventListener(eventType, handler);
    });
    log('input', "".concat(input.name, " (").concat(input.type, ") #").concat(input.id, " useValidationListener() attached: ").concat(validationEvents.join(', '))); // clean listeners function

    var removeAllChangeListeners = () => {
      if (input != undefined) {
        log('input', "".concat(input.name, " (").concat(input.type, ") #").concat(input.id, " useValidationListener() dettaching events"));
        validationEvents.map(eventType => {
          input.removeEventListener(eventType, handler);
        });
      } else {
        log('input', "".concat(input.name, " (").concat(input.type, ") #").concat(input.id, " useValidationListener() WARNING! Could not dettach events"));
      }
    }; // return clean function


    return removeAllChangeListeners;
  }, [inputRef, handler]);
};

var parseForCompare = (inputType, value) => {
  if (value === undefined) {
    return undefined;
  }

  inputType = inputType.toLowerCase();

  if (inputType === 'text' || inputType === 'select') {
    return value.toString();
  }

  if (inputType === 'number') {
    if (value === '' || isNaN(value)) {
      return undefined;
    }

    return parseFloat(value);
  }

  if (inputType === 'checkbox') {
    if (value === true || value === 'true' || value === 1 || value === '1') {
      return true;
    }

    return false;
  }
  /*
  if (inputType==='color') {
    if (value===undefined || value==='') {
      return undefined
    }
    return colorToHex(value)    
  }
   if (inputType==='date') {
    if (value==='' || value === undefined) {
      return undefined
    }
    let vdate= undefined
    if (value instanceof Date) {
      vdate= value
    }
    if (typeof value === 'string') {
      vdate= new Date(value)
    }
    if (typeof value === 'number') {
      vdate= new Date(value * 1000)
    }    
    try {
      vdate= new Date(value)
    } catch(e) {
      console.error(`Formiga: input of type date cannot convert value ${value} to Date`)
      return undefined
    }
    const tdate= `${vdate.getFullYear()}/${vdate.getMonth()+1}/${vdate.getDate()}`
    return tdate    
  }
  */


  if (inputType === 'select-multiple') {
    try {
      return value.sort().join(',');
    } catch (e) {}

    return '';
  }

  return value.toString();
};

//import {log} from '../helpers/log'

var countDecimals = f => {
  try {
    var s = parseFloat(f).toString();

    if (s.indexOf('e-') > 0) {
      return parseInt(s.split('-')[1]);
    }

    return f.toString().split('.')[1].length;
  } catch (e) {
    return 0;
  }
};

var checkValidity = (input, value, checkValue, allowedValues, disallowedValues, doRepeat, doNotRepeat, decimals) => {
  if (input == undefined) {
    return '';
  } // NOTE Manage 'disable' prop? sure?


  if (input.disabled === true) {
    return '';
  } //log('input', `${input.name} (${input.type}) #${input.id} checkValidity() checking...`)


  var name = input.name;
  var inputType = input.type.toLowerCase();
  var vs = input.validity;

  if (vs != undefined) {
    if (vs.badInput) {
      return 'badInput';
    }

    if (vs.patternMismatch) {
      return 'patternMismatch';
    }

    if (vs.rangeOverflow) {
      return 'rangeOverflow';
    }

    if (vs.rangeUnderflow) {
      return 'rangeUnderflow';
    }

    if (vs.tooLong) {
      return 'tooLong';
    }

    if (vs.tooShort) {
      return 'tooShort';
    }

    if (vs.typeMismatch) {
      return 'typeMismatch';
    }

    if (vs.valueMissing) {
      return 'valueMissing';
    }

    if (decimals != undefined && !isNaN(decimals)) {
      //
      // For custom steppable inputs
      //
      if (decimals < countDecimals(value)) {
        return 'stepMismatch';
      }
    }
    /*else if (input.step != undefined) {
    //
    // for non steppable inputs
    //
    if (vs.valid===false  ) { return 'valid' }
    }*/
    else {
      if (vs.stepMismatch) {
        return 'stepMismatch';
      }
    }
  } //log('input', `${input.name} (${input.type}) #${input.id} checkValidity() native validity is ok, doing custom checks...`)
  // When loading document, minlength/maxlength/step constraints are not checked
  // Check this pen: https://codepen.io/afialapis/pen/NWKJoPJ?editors=1111
  // and /issues/validity_on_load


  if (input.maxLength && input.maxLength > 0 && value.length > input.maxLength) {
    return 'tooLong';
  }

  if (input.minLength && input.minLength > 0 && value.length < input.minLength) {
    return 'tooShort';
  }
  /*if (input.step!=undefined && input.step!=='' && input.step!=='any') {
    if (decimals==undefined || isNaN(decimals)) {
      if (countDecimals(input.step)!=countDecimals(value)) {
        return 'stepMismatch'
      }
    }
  }*/
  // Some inputs like hidden and select, wont perform 
  // the standard required validation


  if (input.required && (value == '' || value == undefined)) {
    return 'valueMissing';
  } // Custom validate function


  if (checkValue != undefined) {
    var result = checkValue(value);

    if (result == Promise.resolve(result)) {
      result.then(r => {
        if (!r) {
          return 'customError';
        }
      });
    } else {
      if (!result) {
        return 'customError';
      }
    }
  } // Allowed values list


  if (allowedValues != undefined && value != undefined && value != '') {
    var exists = allowedValues.map(v => parseForCompare(inputType, v)).indexOf(parseForCompare(inputType, value)) >= 0;

    if (!exists) {
      return 'customAllowList';
    }
  } // Disallowed values list


  if (disallowedValues != undefined && value != undefined && value != '') {
    var _exists = disallowedValues.map(v => parseForCompare(inputType, v)).indexOf(parseForCompare(inputType, value)) >= 0;

    if (_exists) {
      return 'customDisallowList';
    }
  } // Must repeat other's input value


  if (doRepeat != undefined && value != undefined && value != '') {
    var otherInput = input.form.elements[doRepeat];

    if (otherInput != undefined) {
      if (otherInput.value != value) {
        return 'customDoRepeat';
      }
    } else {
      if (process.env.NODE_ENV !== "production") {
        console.warn("Formiga: You passed doRepeat=".concat(doRepeat, " to the Input Element (").concat(name, "), but there is no input with that name"));
      }
    }
  } // Do not repeat other's input value


  if (doNotRepeat != undefined && value != undefined && value != '') {
    var _otherInput = input.form.elements[doNotRepeat];

    if (_otherInput != undefined) {
      if (_otherInput.value == value) {
        return 'customDoNotRepeat';
      }
    } else {
      if (process.env.NODE_ENV !== "production") {
        console.warn("Formiga: You passed doNotRepeat=".concat(doNotRepeat, " to the Input Element (").concat(name, "), but there is no input with that name"));
      }
    }
  }

  return '';
};

//import {log} from '../helpers/log'
var getInputValue = input => {
  var inputType = input.type.toLowerCase();

  if (inputType == 'checkbox') {
    return input.checked;
  }

  if (inputType == 'select-multiple') {
    var options = Array.prototype.slice.call(input.options);
    var value = options.filter(opt => opt.selected).map(opt => opt.value);
    return value;
  }

  if (inputType == 'file') {
    try {
      return input.files[0];
    } catch (e) {
      console.error("Formiga: error on input ".concat(input.name, " of type file: ").concat(e.message));
      console.error(e);
      return undefined;
    }
  }
  /*
   // TO CHECK: When do we need this?
  if (input.value==undefined) {
    return ''
  }
  */


  return input.value;
};

var getEventTarget = event => {
  if ((event === null || event === void 0 ? void 0 : event.target) == undefined) {
    return undefined;
  }

  if (event.target.tagName.toLowerCase() == 'option') {
    return event.target.closest('select');
  }

  return event.target;
};

var DEFAULT_MESSAGES = {
  badInput: 'Value is wrong',
  customError: 'Value does not match custom validity',
  patternMismatch: 'Value does not match expected pattern',
  rangeOverflow: 'Value is greater than expected',
  rangeUnderflow: 'Value is lesser than expected',
  stepMismatch: 'Value has an incorrect number of decimals',
  tooShort: 'Value is shorter than expected',
  tooLong: 'Value is longer than expected',
  typeMismatch: 'Value type is wrong',
  valueMissing: 'Value is required',
  valid: 'Value is not valid',
  // custom validations
  customAllowList: 'Value is not allowed',
  customDisallowList: 'Value is disallowed',
  customDoRepeat: 'Value must be repeated',
  customDoNotRepeat: 'Value cannot be repeated'
};

var getDefaultMessage = n => DEFAULT_MESSAGES[n];

var useValidationHandler = (transformValue, checkValue, allowedValues, disallowedValues, doRepeat, doNotRepeat, decimals, feedback) => {
  var [validity, setValidity] = react.useState(false);
  var handler = react.useCallback((event, inputRef) => {
    var input = event ? getEventTarget(event) : inputRef === null || inputRef === void 0 ? void 0 : inputRef.current;
    var nValidity = '';

    if (input != undefined) {
      // Clear previous custom error
      input.setCustomValidity('');
      input.setAttribute('data-formiga-validity', '');
      input.removeAttribute('data-formiga-value'); // Get input value

      var value = getInputValue(input);

      if (transformValue != undefined) {
        value = transformValue(value);
      } // Check validity


      var chkValidity = checkValidity(input, value, checkValue, allowedValues, disallowedValues, doRepeat, doNotRepeat, decimals);
      nValidity = chkValidity == '' ? '' : feedback != undefined ? feedback : getDefaultMessage(chkValidity); // Set it
      //input.removeAttribute('readonly')

      input.setCustomValidity(nValidity);
      input.setAttribute('data-formiga-validity', nValidity);
      input.setAttribute('data-formiga-value', value); // Update form     

      if (input.form != undefined) {
        //log('input', `${input.name} (${input.type}) #${input.id} validationHandler() is raising formiga-form-change`)
        var _event = new CustomEvent("formiga-form-change", {
          detail: {
            name: input.name,
            validity: nValidity,
            valid: nValidity == '',
            value: value
          }
        });

        input.form.dispatchEvent(_event);
      }

      log('input', "".concat(input.name, " (").concat(input.type, ") #").concat(input.id, " validationHandler() new validity is -").concat(nValidity || 'ok', "-"));
    }

    setValidity(nValidity);
  }, [transformValue, checkValue, allowedValues, disallowedValues, doRepeat, doNotRepeat, decimals, feedback]);
  return [validity, handler];
};

var useInput = props => {
  var _inputRef$current, _inputRef$current2, _inputRef$current3, _inputRef$current4, _inputRef$current5;

  var {
    transformValue,
    checkValue,
    allowedValues,
    disallowedValues,
    doRepeat,
    doNotRepeat,
    decimals,
    inputFilter,
    feedback
  } = props;
  var inputRef = react.useRef(undefined); //
  // Specific effect to check props consistency. Just DEV time
  //

  useCheckProps(inputRef, doRepeat, doNotRepeat, inputFilter); //
  // Attaches input filters when needed
  //

  useInputFilter(inputRef, inputFilter); //
  // Ensures checkboxes value
  //
  //useCheckboxEnsure(inputRef)
  // 
  // Get validation handler and current validity
  //

  var [validity, handler] = useValidationHandler(transformValue, checkValue, allowedValues, disallowedValues, doRepeat, doNotRepeat, decimals, feedback); //
  // Attaches validation listeners
  //

  useValidationListener(inputRef, handler); //
  // Runs validations from out of Formiga
  //

  var setValidity = react.useCallback(() => {
    handler(undefined, inputRef);
  }, [handler]); //
  // Runs validity checks on mount
  //

  react.useEffect(() => {
    setValidity();
  }, [setValidity, inputRef === null || inputRef === void 0 ? void 0 : (_inputRef$current = inputRef.current) === null || _inputRef$current === void 0 ? void 0 : _inputRef$current.value]);
  log('input', "Render, ".concat(inputRef === null || inputRef === void 0 ? void 0 : (_inputRef$current2 = inputRef.current) === null || _inputRef$current2 === void 0 ? void 0 : _inputRef$current2.name, " (").concat(inputRef === null || inputRef === void 0 ? void 0 : (_inputRef$current3 = inputRef.current) === null || _inputRef$current3 === void 0 ? void 0 : _inputRef$current3.type, ") #").concat(inputRef === null || inputRef === void 0 ? void 0 : (_inputRef$current4 = inputRef.current) === null || _inputRef$current4 === void 0 ? void 0 : _inputRef$current4.id, " useInput (value ").concat(inputRef === null || inputRef === void 0 ? void 0 : (_inputRef$current5 = inputRef.current) === null || _inputRef$current5 === void 0 ? void 0 : _inputRef$current5.value, ")"));
  return [inputRef, validity === '', validity, setValidity];
};

exports.useForm = useForm;
exports.useInput = useInput;
exports.useInputFilter = useInputFilter;
